﻿using UnityEngine;

using _Game.Core;                        // GameContext
using _Game.Core.DI;                     // BaseInstaller
using _Game.Interfaces;                  // IDIContainer, IUpdatableSystem, IEventBus

// Board
using _Game.Runtime.Board;               // BoardSurface, BoardGrid, GridProjector, ScreenSpaceRayProvider

// Characters
using _Game.Runtime.Characters;          // CharacterPoolRegistry, CharacterFactory, CharacterRepository, CharacterSystem

// Placement & Selection (DEFENSE flow)
using _Game.Runtime.Placement;           // PlacementValidator, PlacementPreviewService
using _Game.Runtime.Selection;           // CharacterSelectionSpawner, CharacterSelectionSystem

// Level
using _Game.Runtime.Levels;              // LevelCatalogue, LevelRuntimeConfig

// Combat
using _Game.Runtime.Combat;
using _Game.Runtime.Core; // EnemySpawnerSystem, ProjectileSystem

// Visuals & Systems
using _Game.Runtime.Systems;             // PointerHoverSystem
using _Game.Runtime.Visuals;             // GridVisualsService

// Utils
using _Game.Utils;                       // GameObjectPool

namespace _Game.Core.DI
{
    /// <summary>
    /// Scene-level wiring for board/grid, characters, projectiles, enemy spawns,
    /// defense selection/placement, and grid visuals.
    /// </summary>
    public sealed class RuntimeInstaller : BaseInstaller
    {
        // ---------- Scene ----------
        [Header("Scene")]
        [SerializeField] private BoardSurface boardSurface;
        [SerializeField] private Camera targetCamera;

        // ---------- Parents ----------
        [Header("Parents")]
        [SerializeField] private Transform unitsParent;
        [SerializeField] private Transform projectilesParent;

        // ---------- Level ----------
        [Header("Level")]
        [SerializeField] private LevelCatalogue levelCatalogue;
        [SerializeField] private string levelId = "Level-1";

        // ---------- Projectiles ----------
        [Header("Projectiles (optional prefab)")]
        [SerializeField] private GameObject projectilePrefab;

        // ---------- Selection / Placement (DEFENSE flow) ----------
        [Header("Selection / Placement")]
        [SerializeField] private Transform selectionModelsParent;
        [SerializeField] private Transform selectionSpawnPoint;
        [SerializeField, Min(0.25f)] private float selectionSpacing = 2f;
        [SerializeField, Min(0.1f)] private float selectionPickRadius = 1.0f;

        public override void Install(IDIContainer container)
        {
            var events  = GameContext.Events;
            var systems = GameContext.Systems;

            // ---- Guards ----
            if (!boardSurface) { Debug.LogError("[RuntimeInstaller] BoardSurface is not assigned."); return; }
            if (!targetCamera) targetCamera = Camera.main;
            if (!targetCamera) { Debug.LogError("[RuntimeInstaller] No Camera assigned and no MainCamera found."); return; }
            if (!levelCatalogue) { Debug.LogError("[RuntimeInstaller] LevelCatalogue is not assigned."); return; }

            // ==== Core: grid & projection ====
            var rayProvider = new ScreenSpaceRayProvider(targetCamera);
            container.BindSingleton<IRayProvider>(rayProvider);

            var grid = new BoardGrid(boardSurface.rows, boardSurface.cols, boardSurface.cellSize);
            var projector = new GridProjector(grid, boardSurface);

            container.BindSingleton(boardSurface);
            container.BindSingleton(grid);
            container.BindSingleton(projector);

            // ==== Level runtime ====
            var levelData = levelCatalogue.GetById(levelId);
            if (levelData == null) { Debug.LogError($"[RuntimeInstaller] Level '{levelId}' not found in catalogue."); return; }
            var level = new LevelRuntimeConfig(levelData);
            container.BindSingleton(level);

            // ==== Parents ====
            if (!unitsParent)
            {
                unitsParent = new GameObject("Units").transform;
                unitsParent.SetParent(boardSurface.transform, true);
            }
            if (!projectilesParent)
            {
                projectilesParent = new GameObject("Projectiles").transform;
                projectilesParent.SetParent(boardSurface.transform, true);
            }
            if (!selectionModelsParent)
            {
                selectionModelsParent = new GameObject("SelectionModels").transform;
                selectionModelsParent.SetParent(boardSurface.transform, true);
            }
            if (!selectionSpawnPoint)
            {
                selectionSpawnPoint = new GameObject("SelectionSpawnPoint").transform;
                selectionSpawnPoint.SetParent(boardSurface.transform, true);
                selectionSpawnPoint.position = boardSurface.transform.position;
            }

            // ==== Characters stack ====
            var pools      = new CharacterPoolRegistry();
            var repo       = new CharacterRepository();
            var factory    = new CharacterFactory(pools);
            var charSystem = new CharacterSystem(); // must call OnSpawn in Register

            container.BindSingleton(pools);
            container.BindSingleton(repo);
            container.BindSingleton(factory);
            container.BindSingleton(charSystem);
            systems.Register((IUpdatableSystem)charSystem);

            // ==== Projectile pool + system ====
            if (projectilePrefab == null)
            {
                projectilePrefab = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                projectilePrefab.name = "Projectile";
                projectilePrefab.transform.localScale = Vector3.one * 0.1f;
                var col = projectilePrefab.GetComponent<Collider>();
                if (col) Object.Destroy(col);
            }

            // NOTE: correct arg name is 'initialCapacity'
            var projectilePool   = new GameObjectPool(projectilePrefab, initialSize: 32, parent: projectilesParent);
            var projectileSystem = new ProjectileSystem(events, repo, projectilePool);
            systems.Register((IUpdatableSystem)projectileSystem);

            // ==== Enemy spawner (top row, random column) ====
            var spawner = new EnemySpawnerSystem(grid, projector, factory, repo, level, unitsParent);
            systems.Register((IUpdatableSystem)spawner);

            // ==== DEFENSE selection + placement ====
            var validator = new PlacementValidator(repo, grid);
            container.BindSingleton(validator);

            var previewSvc = new PlacementPreviewService(factory, boardSurface, projector, validator, unitsParent);
            container.BindSingleton(previewSvc);

            var selectionSpawner = new CharacterSelectionSpawner(level, selectionSpawnPoint, selectionSpacing, selectionModelsParent);
            var selectables = selectionSpawner.Spawn();

            var selectionSystem = new CharacterSelectionSystem(
                rayProvider, projector, grid, boardSurface,
                factory, repo, validator, unitsParent,
                selectables, events, dragLift: 0.01f);
            systems.Register((IUpdatableSystem)selectionSystem);

            // ==== GRID VISUALS + HOVER ====
            // 1) Publisher: emits HoverCellChangedEvent each frame
            var hoverSystem = new _Game.Runtime.Systems.PointerHoverSystem(rayProvider, boardSurface, projector, events);
            systems.Register((IUpdatableSystem)hoverSystem);

            // 2) Visuals: build placeable markers + hover quad
            var cellQuad = GameObject.CreatePrimitive(PrimitiveType.Quad);
            cellQuad.name = "CellMarker";
            cellQuad.transform.localScale = new Vector3(boardSurface.cellSize * 0.95f, boardSurface.cellSize * 0.95f, 1f);
            Object.Destroy(cellQuad.GetComponent<Collider>());

            var hoverQuad = GameObject.CreatePrimitive(PrimitiveType.Quad);
            hoverQuad.name = "HoverMarker";
            hoverQuad.transform.localScale = new Vector3(boardSurface.cellSize * 0.95f, boardSurface.cellSize * 0.95f, 1f);
            Object.Destroy(hoverQuad.GetComponent<Collider>());

            var placeablePool = new GameObjectPool(cellQuad, initialSize: grid.Size.Rows * grid.Size.Cols, parent: boardSurface.transform);
            var gridVisuals = new _Game.Runtime.Visuals.GridVisualsService(grid, boardSurface, projector, events, placeablePool, hoverQuad, boardSurface.transform, 0.01f);
            container.BindSingleton(gridVisuals);
        }
    }
}
