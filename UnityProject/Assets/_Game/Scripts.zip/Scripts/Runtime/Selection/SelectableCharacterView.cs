﻿using _Game.Runtime.Characters.Config;
using UnityEngine;

namespace _Game.Runtime.Selection
{
    public class SelectableCharacterView : MonoBehaviour
    {
        private CharacterArchetype _archetype;
        private Vector3 _initialPosition;


        public void Initialize(CharacterArchetype archetype)
        {
            _archetype = archetype;
            _initialPosition = transform.position;
        }


        public void ResetPosition()
        {
            transform.position = _initialPosition;
        }


        public CharacterArchetype Archetype => _archetype;
    }
}