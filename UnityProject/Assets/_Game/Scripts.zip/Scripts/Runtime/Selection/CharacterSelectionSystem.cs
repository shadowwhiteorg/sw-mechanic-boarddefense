﻿using System.Collections.Generic;
using _Game.Enums;
using UnityEngine;
using _Game.Interfaces;
using _Game.Runtime.Board;
using _Game.Runtime.Characters;
using _Game.Runtime.Core;
using _Game.Runtime.Placement;

namespace _Game.Runtime.Selection
{
    /// <summary>
    /// Pure NO-PHYSICS selection + drag-to-place:
    /// - MouseDown: pick nearest selectable on a math plane around spawn point (radius-based).
    /// - While held: snap the selected to hovered grid cell center via GridProjector.
    /// - MouseUp: place if valid; else snap back to initial position.
    /// </summary>
    public sealed class CharacterSelectionSystem : IUpdatableSystem
    {
        private readonly IRayProvider _rayProvider;
        private readonly GridProjector _projector;
        private readonly BoardGrid _grid;
        private readonly CharacterFactory _factory;
        private readonly CharacterRepository _repo;
        private readonly PlacementValidator _validator;
        private readonly Transform _placedParent;
        private readonly IReadOnlyList<SelectableCharacterView> _selectables;
        private readonly Transform _selectionPlaneRef;
        private readonly float _pickRadius;

        private SelectableCharacterView _selected;
        private bool _dragging;

        /// <param name="rayProvider">Converts screen pointer to Ray (no physics used).</param>
        /// <param name="projector">Grid projector for screen↔world↔cell conversions.</param>
        /// <param name="grid">Board grid (bounds/size).</param>
        /// <param name="factory">Spawner for final placed unit.</param>
        /// <param name="repo">Registers occupancy per cell.</param>
        /// <param name="validator">Rules for allowed placement.</param>
        /// <param name="placedParent">Parent for placed units.</param>
        /// <param name="selectables">Spawned selection models to pick from.</param>
        /// <param name="selectionPlaneRef">Plane anchor (usually selection spawn point transform).</param>
        /// <param name="pickRadius">World-units pick radius on that plane.</param>
        public CharacterSelectionSystem(
            IRayProvider rayProvider,
            GridProjector projector,
            BoardGrid grid,
            CharacterFactory factory,
            CharacterRepository repo,
            PlacementValidator validator,
            Transform placedParent,
            IReadOnlyList<SelectableCharacterView> selectables,
            Transform selectionPlaneRef,
            float pickRadius = 10.0f)
        {
            _rayProvider       = rayProvider;
            _projector         = projector;
            _grid              = grid;
            _factory           = factory;
            _repo              = repo;
            _validator         = validator;
            _placedParent      = placedParent;
            _selectables       = selectables;
            _selectionPlaneRef = selectionPlaneRef;
            _pickRadius        = Mathf.Max(0.05f, pickRadius);
        }

        public void Tick()
        {
            if (!_dragging && Input.GetMouseButtonDown(0))
                TryBeginDrag();

            if (_dragging && _selected != null)
            {
                // Follow the centered cell under pointer (no physics)
                if (_projector.TryWorldToCell(Input.mousePosition, out var cell))
                {
                    var centerWorld = _projector.CellToWorldCenter(cell);
                    _selected.transform.position = centerWorld;

                    if (Input.GetMouseButtonUp(0))
                        EndDrag(cell);
                }
                else
                {
                    // No cell under pointer — if released now, cancel to origin
                    if (Input.GetMouseButtonUp(0))
                        CancelDrag();
                }
            }
        }

        private void TryBeginDrag()
        {
            var ray = _rayProvider.PointerToRay(Input.mousePosition);
            if (!TryRayPlane(ray, _selectionPlaneRef.position, Vector3.up, out var hitOnPlane))
                return;

            SelectableCharacterView best = null;
            float bestDist2 = _pickRadius * _pickRadius;

            for (int i = 0; i < _selectables.Count; i++)
            {
                var v = _selectables[i];
                if (v == null) continue;

                float d2 = (v.transform.position - hitOnPlane).sqrMagnitude;
                if (d2 <= bestDist2)
                {
                    bestDist2 = d2;
                    best = v;
                }
            }

            if (best != null)
            {
                _selected = best;
                _dragging = true;
            }
        }

        private void EndDrag(Cell cell)
        {
            _dragging = false;

            if (_validator.IsValid(cell))
            {
                var entity = _factory.Spawn(_selected.Archetype, cell, _placedParent, CharacterRole.Defense);
                _repo.Add(entity, cell);

                // Remove the selection model (we placed the real unit)
                Object.Destroy(_selected.gameObject);
            }
            else
            {
                _selected.ResetPosition();
            }

            _selected = null;
        }

        private void CancelDrag()
        {
            _dragging = false;
            _selected.ResetPosition();
            _selected = null;
        }

        /// <summary>Ray → plane intersection without Physics.</summary>
        private static bool TryRayPlane(Ray ray, Vector3 planePoint, Vector3 planeNormal, out Vector3 hit)
        {
            hit = default;
            float denom = Vector3.Dot(ray.direction, planeNormal);
            if (Mathf.Abs(denom) < 1e-5f) return false; // ray ~ parallel to plane
            float t = Vector3.Dot(planePoint - ray.origin, planeNormal) / denom;
            if (t < 0f) return false;
            hit = ray.origin + ray.direction * t;
            return true;
        }
    }
}
