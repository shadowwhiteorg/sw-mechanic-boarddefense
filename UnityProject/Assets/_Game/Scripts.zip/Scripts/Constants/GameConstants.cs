﻿namespace _Game.Core.Constants
{
    public static class GameConstants
    {
        public const string PlayerPrefsLevel = "LevelNr";
    }
}