﻿namespace _Game.Interfaces
{
    public interface IDefenseRole
    {
        
    }
}