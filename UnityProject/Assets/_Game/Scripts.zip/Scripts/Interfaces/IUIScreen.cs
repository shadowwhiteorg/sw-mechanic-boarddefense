﻿namespace _Game.Interfaces
{
    public interface IUIScreen
    {
        void Show();
        void Hide();
    }
}