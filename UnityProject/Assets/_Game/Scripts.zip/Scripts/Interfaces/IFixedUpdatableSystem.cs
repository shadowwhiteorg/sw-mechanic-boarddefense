﻿namespace _Game.Interfaces
{
    public interface IFixedUpdatableSystem
    {
        void FixedTick();
    }
}