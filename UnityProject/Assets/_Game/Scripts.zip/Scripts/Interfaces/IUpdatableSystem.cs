﻿namespace _Game.Interfaces
{
    public interface IUpdatableSystem
    {
        void Tick();
    }
}