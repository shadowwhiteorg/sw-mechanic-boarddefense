﻿namespace _Game.Interfaces
{
    public class IEnemyRole
    {
        
    }
}