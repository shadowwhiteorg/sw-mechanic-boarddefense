﻿namespace _Game.Interfaces
{
    public interface IMovement : ICharacterPlugin
    {
        
    }
}