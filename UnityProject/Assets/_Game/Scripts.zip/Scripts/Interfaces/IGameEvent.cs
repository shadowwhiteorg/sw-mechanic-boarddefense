﻿namespace _Game.Interfaces
{
    public interface IGameEvent
    {
        
    }
}