﻿namespace _Game.Enums
{
    public enum Ease
    {
        Linear,
        InQuad,
        OutQuad,
        InOutQuad
    }
}