﻿namespace _Game.Enums
{
    public enum CharacterRole
    {
        Defense = 0,
        Enemy =1
    }
}