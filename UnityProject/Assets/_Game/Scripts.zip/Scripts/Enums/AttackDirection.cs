﻿namespace _Game.Enums
{
    public enum AttackDirection
    {
        Forward = 0,
        All     = 1
    }
}